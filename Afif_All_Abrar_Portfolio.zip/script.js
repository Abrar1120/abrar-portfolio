const sections = document.querySelectorAll('.fade-in');
function revealOnScroll() {
  sections.forEach(sec => {
    const rect = sec.getBoundingClientRect();
    if (rect.top < window.innerHeight - 100) {
      sec.classList.add('visible');
    }
  });
}
window.addEventListener('scroll', revealOnScroll);
revealOnScroll();
function scrollToSection(id) {
  document.getElementById(id).scrollIntoView({ behavior: "smooth" });
}
const typingElement = document.querySelector(".typing");
const words = ["Coder 💻", "Learner 📚"];
let wordIndex = 0, charIndex = 0, isDeleting = false;
function typeEffect() {
  const currentWord = words[wordIndex];
  typingElement.textContent = `I'm a ${currentWord.substring(0, charIndex)}`;
  if (!isDeleting && charIndex < currentWord.length) charIndex++;
  else if (isDeleting && charIndex > 0) charIndex--;
  else {
    isDeleting = !isDeleting;
    if (!isDeleting) wordIndex = (wordIndex + 1) % words.length;
  }
  setTimeout(typeEffect, isDeleting ? 80 : 150);
}
typeEffect();
function toggleMenu() {
  document.querySelector('.navbar').classList.toggle('active');
}
